package com.example.eventtrackingapp

data class Event(
    val title: String,
    val time: String
)
